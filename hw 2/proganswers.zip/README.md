- Just run each block of "Spam Detection HW2 .ipynb" from up to down, all the answers will be shown as below.

- I difine the value of "m" at the last block, line 5. If you want to try different values, you can modify the value here.

- The estimated phi matrix for the Bernoulli for each attribute x and each class y is huge, if you don't want to see these, you can comment out the code below.

  ```python
  print(bern_matrix_y0.tolist())
  
  print(bern_matrix_y1.tolist())
  ```

- If you have any question, feel free to contact yl6606@nyu.edu or foxerlee1@gmail.com

